﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Dapper;
using NUnit.Framework;
using Steps.Helpers;
using TechTalk.SpecFlow;
using UnitTests.Framework.Helpers;
using UnitTests.Framework.Interfaces;

namespace UnitTests.Framework.Database
{
    public sealed class SqlDatabase : IDisposable, ISqlDatabase
    {
        private readonly IDbConnection _connection;

        private readonly int _ssisTimeoutSeconds;

        private readonly int _sqlCommandTimeoutSeconds;

        public SqlDatabase(string connectionString, int ssisTimeoutSeconds, int sqlCommandTimeoutSeconds)
        {
            _connection = new SqlConnection(connectionString);
            _ssisTimeoutSeconds = ssisTimeoutSeconds;
            _sqlCommandTimeoutSeconds = sqlCommandTimeoutSeconds;
        }

        public async Task InsertAsync(string databaseName, string tableName, TypedTable table)
        {
            await InsertAsync(databaseName, tableName, table.ToDictionaries());
        }

        public async Task InsertAsync(string databaseName, string name, IEnumerable<Dictionary<string, object>> rows)
        {
            foreach (var row in rows)
            {
                var columns = string.Join(",", row.Keys);
                var values = string.Join(",", row.Keys.Select(k => $"@{k}"));
                var sql = $"INSERT INTO {name} ({columns}) VALUES ({values})";
                try
                {
                    await ExecuteCommandAsync(databaseName, sql, row);
                }
                catch
                {
                    TestContext.WriteLine($"Insert SQL Error Table {name}: {sql}");
                    throw;
                }
            }
        }

        public async Task SelectIntoAsync(string databaseName, string tableName, TypedTable table)
        {
            var sql = table.SelectIntoStatement(tableName);

            try
            {
                await ExecuteCommandAsync(databaseName, sql);
            }
            catch
            {
                TestContext.WriteLine($"Insert SQL Error Table {tableName}: {sql}");
                throw;
            }
        }

        public async Task MockViewAsync(string databaseName, string viewName)
        {
            var (_, schema, view) = SplitSchemaTableName(viewName);
            var sql = $@"USE {databaseName}
                         IF EXISTS (
                                SELECT 1 FROM INFORMATION_SCHEMA.TABLES AS t WHERE t.TABLE_NAME = '{view}' AND t.TABLE_SCHEMA = '{schema}' AND t.TABLE_TYPE != 'VIEW'
                            ) RAISERROR ('YOU CANT MOCK {databaseName}.{schema}.{view} ONLY VIEWS ARE ALLOWED',16,1)                         

                         IF OBJECT_ID('{schema}.{view}_BeingMocked') IS NULL
                            EXEC sys.sp_rename @objname = N'{schema}.{view}', @newname = '{view}_BeingMocked', @objtype = 'object'
                         DROP TABLE IF EXISTS {schema}.{view}
                         DROP TABLE IF EXISTS {schema}.{view}_Mock
                         
                         -- This self join is to force all columns to be nullable
                         select top 0
                           B.*
                         into
                           {schema}.{view}
                         from
                           {schema}.{view}_BeingMocked as A
                             left join {schema}.{view}_BeingMocked as B on 1 = 0";
            try
            {
                await ExecuteCommandAsync(databaseName, sql);
            }
            catch
            {
                TestContext.Error.WriteLine($"MockView SQL Error: {sql}");
                throw;
            }
        }

        public async Task<List<Dictionary<string, string>>> GetForeignKeysNamesFromTable(string databaseName, string tableName)
        {
            var sql = $@"USE {databaseName}
                        SELECT name as ForeignKeyName, SCHEMA_NAME(schema_id) + '.' + OBJECT_NAME(parent_object_Id) as parentTableName
                        FROM sys.foreign_keys
                        WHERE OBJECT_NAME(referenced_object_id)='{tableName}'";
            var results = new List<Dictionary<string, string>>();
            try
            {
                var reader = await GetConnection(databaseName).ExecuteReaderAsync(sql, commandTimeout: 0);
                while (reader.Read())
                {
                    var foreignKeyAndReferenceTableDictionary = new Dictionary<string, string>
                    {
                        { reader.GetString(0), reader.GetString(1) }
                    };
                    results.Add(foreignKeyAndReferenceTableDictionary);
                }
                reader.Close();
            }
            catch
            {
                TestContext.Error.WriteLine($"Getting table names from database error: {sql}");
                throw;
            }
            return results;
        }

        public async Task DropForeignKeyContraint(string databaseName, string fullTableName, string foreignKeyName)
        {
            var sql = $@"USE {databaseName}
                         ALTER TABLE {fullTableName} 
                         DROP CONSTRAINT {foreignKeyName}";
            try
            {
                await ExecuteCommandAsync(databaseName, sql);
            }
            catch
            {
                TestContext.Error.WriteLine($"error: {sql}");
                throw;
            }
        }

        public async Task DropForeignKeyConstraintsFromTable(string databaseName, string tableNameWithSchema)
        {
            var tableName = tableNameWithSchema.Split(".")[1];
            var foreignKeysAndParentTableNames = await GetForeignKeysNamesFromTable(databaseName, tableName);

            foreach (var foreignKeyAndParentTableName in foreignKeysAndParentTableNames)
            {
                await DropForeignKeys(databaseName, foreignKeyAndParentTableName);
            }
        }

        public async Task DropViewsWithSchemaBindingToTable(string databaseName, string tableNameWithSchema)
        {
            var parts = tableNameWithSchema.Split(".");

            var viewNames = await GetViewNamesWithSchemaBindingToTable(databaseName, parts[0], parts[1]);
            foreach( var viewName in viewNames)
            {
                await DropViewAsync(databaseName, viewName);
            }
        }

        public async Task<List<string>> GetViewNamesWithSchemaBindingToTable(string databaseName, string schemaName, string tableName)
        {
            var sql = $@"USE {databaseName}
                      SELECT SCHEMA_NAME(v.schema_id) + '.' + OBJECT_NAME(v.object_id) AS referencingViewWithSchemaBinding
                      FROM sys.sql_expression_dependencies sed
                          INNER JOIN sys.views v
                              ON sed.referencing_id = v.object_id
                      WHERE sed.referenced_entity_name = '{tableName}'
                      AND sed.referenced_schema_name = '{schemaName}'
                      AND sed.is_schema_bound_reference = 1";
            var results = new List<string>();
            try
            {
                var reader = await GetConnection(databaseName).ExecuteReaderAsync(sql, commandTimeout: 0);
                while (reader.Read())
                {
                    results.Add(reader.GetString(0));
                }
                reader.Close();
            }
            catch
            {
                TestContext.Error.WriteLine($"Getting view names with schema binding from database error: {sql}");
                throw;
            }
            return results;
        }

        private async Task DropForeignKeys(string databaseName, Dictionary<string, string> foreignKeyAndParentTableName)
        {
            foreach (var kv in foreignKeyAndParentTableName)
            {
                var foreignKeyName = kv.Key;
                var parentTableName = kv.Value;
                await DropForeignKeyContraint(databaseName, parentTableName, foreignKeyName);
            }
        }

        public async Task MockProcedureAsync(string databaseName, string procedureName, string commandToExecute = null)
        {
            await ExecProcAsync(databaseName, "tSQLt.SpyProcedure", new Dictionary<string, object>()
            {
                {"ProcedureName ", procedureName },
                {"CommandToExecute ", commandToExecute }
            });
        }

        public async Task FakeFunctionAsync(string databaseName, string fqViewName, string returnSql)
        {
            var fakeName = $"{fqViewName}_FAKE";
            var definition = (await GetObjectDefinitionAsync(databaseName, fqViewName)).Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
            var funcSignaturePattern = new Regex(@"CREATE FUNCTION .*?(\(.*?\).*?) (BEGIN|RETURNS TABLE AS RETURN)", RegexOptions.IgnoreCase);

            var match = funcSignaturePattern.Match(definition);
            if (!match.Success) throw new Exception("Invalid parameter definition pattern");
            var parameters = match.Groups[1].Value;
            var funcBegin = match.Groups[2].Value;
            var funcEnd = funcBegin == "BEGIN" ? "END" : "";

            var connection = GetConnection(databaseName);
            await connection.ExecuteAsync($"DROP FUNCTION IF EXISTS {fakeName}");
            var sqlCreateFakeFunc = $"CREATE FUNCTION {fakeName} {parameters} {funcBegin} {returnSql} {funcEnd}";
            await connection.ExecuteAsync(sqlCreateFakeFunc);

            await ExecProcAsync(databaseName, "tSQLt.FakeFunction", new Dictionary<string, object>()
            {
                {"FunctionName", fqViewName },
                {"FakeFunctionName", fakeName }
            });
        }

        public async Task UnMockViewAsync(string databaseName)
        {
            var sql = $@"USE {databaseName}
                                    DECLARE @SchemaName VARCHAR(200)
                                    DECLARE @TableName VARCHAR(200)
                                    DECLARE @loopCnt INT = 1
                                    DECLARE @tblCnt INT = 0
                                    DROP TABLE IF EXISTS #tbls
                                    SELECT ROW_NUMBER() OVER (ORDER BY t.TABLE_SCHEMA, t.TABLE_NAME) AS tblId
                                            , t.TABLE_SCHEMA
                                            , REPLACE(t.TABLE_NAME,'_BeingMocked', '') AS TABLE_NAME
                                    INTO   #tbls
                                    FROM   INFORMATION_SCHEMA.VIEWS AS t
                                    WHERE t.TABLE_NAME LIKE '%_BeingMocked'

                                    SELECT @tblCnt = @@ROWCOUNT

                                    WHILE @loopCnt <= @tblCnt
                                    BEGIN
                                        SELECT @SchemaName = t.TABLE_SCHEMA
                                                , @TableName  = t.TABLE_NAME
                                                , @loopCnt = @loopCnt + 1
                                        FROM   #tbls AS t
                                        WHERE  t.tblId = @loopCnt

	                                    DECLARE @UnMockViewSql NVARCHAR(MAX) = N'
	                                    BEGIN TRY EXEC sys.sp_rename @objname = N''<TABLE_SCHEMA>.<TABLE_NAME>'', @newname = ''<TABLE_NAME>_mock'' END TRY BEGIN CATCH END CATCH
	                                    BEGIN TRY EXEC sys.sp_rename @objname = N''<TABLE_SCHEMA>.<TABLE_NAME>_BeingMocked'', @newname = ''<TABLE_NAME>'' END TRY BEGIN CATCH END CATCH'
	                                    SET @UnMockViewSql  = REPLACE(@UnMockViewSql ,'<TABLE_SCHEMA>',@SchemaName)
	                                    SET @UnMockViewSql  = REPLACE(@UnMockViewSql ,'<TABLE_NAME>',@TableName)
	                                                                        
	                                    EXEC sys.sp_executesql @UnMockViewSql
                                    END";
            await ExecuteCommandAsync(databaseName, sql);
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ReadAllAsync(string databaseName, string tableName)
        {
            var sql = $"SELECT * FROM {tableName}";
            return (await GetConnection(databaseName).QueryAsync(sql)).Select(d => (IDictionary<string, object>)d);
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ReadColumnDetailsAsync(string databaseName, string tableName, IEnumerable<string> columnsToIgnore = null)
        {
            var exclusionClause = "";
            if (columnsToIgnore != null)
            {
                var columnsToIgnoreString = string.Join(",", columnsToIgnore.Select(col => $"'{col}'"));
                exclusionClause = $"AND COLUMN_NAME NOT IN ({columnsToIgnoreString})";
            }

            var sql = $@"SELECT LOWER(COLUMN_NAME), DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, DATETIME_PRECISION
                         FROM [INFORMATION_SCHEMA].[COLUMNS]
                         WHERE CONCAT(TABLE_SCHEMA, '.', TABLE_NAME) = '{tableName}'
                         {exclusionClause}
                         ORDER BY COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, DATETIME_PRECISION";
            var columnDetails = (await GetConnection(databaseName).QueryAsync(sql)).Select(d => (IDictionary<string, object>)d).ToList();

            if (columnDetails.Count == 0) throw new ArgumentException($"No schema details found for {tableName}");

            return columnDetails;
        }

        public async Task TruncateAsync(string databaseName, string tableName)
        {
            try
            {
                await ExecuteCommandAsync(databaseName, $"TRUNCATE TABLE {tableName}");
            }
            catch (SqlException sqlEx)
            {
                if (!sqlEx.Message.Contains("because it is not a table"))
                    throw;

                await ExecuteCommandAsync(databaseName, $"DELETE FROM {tableName}");
            }
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ExecProcAsync(string databaseName, string procName, Table parameters)
        {
            return await ExecProcAsync(databaseName, procName, parameters.ToDictionary());
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ExecProcAsync(string databaseName, string procName)
        {
            return (await GetConnection(databaseName).QueryAsync(procName, commandType:CommandType.StoredProcedure)).Select(d => (IDictionary<string, object>)d);
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ExecProcWithResultsAsync(string databaseName, string procName, IDictionary<string, object> parameters)
        {
            var results = new List<IDictionary<string, object>>();
            using (var reader = await GetConnection(databaseName).ExecuteReaderAsync(procName, parameters, commandType: CommandType.StoredProcedure))
            {
                while (reader.Read())
                {
                    results.Add(Enumerable.Range(0, reader.FieldCount).ToDictionary(reader.GetName, reader.GetValue));
                }
            }

            return results;
        }

        public async Task DropNotNullConstraintsAsync(string databaseName, string name)
        {
            var (_, schema, table) = SplitSchemaTableName(name);
            var sql = $@"USE {databaseName}     
            
            DROP TABLE IF EXISTS {schema}.{table}_NEW;

            select top 0
                B.*
                    into
                {schema}.{table}_NEW
             from
                {schema}.{table} as A
                left join {schema}.{table}
                as B on 1 = 0
            
            DROP TABLE {schema}.{table}
            
            EXEC sys.sp_rename @objname = N'{schema}.{table}_NEW', @newname = '{table}', @objtype = 'object'";
            await ExecuteCommandAsync(databaseName, sql);
        }

        public async Task<int> ExecuteSsisAndWaitAsync(string databaseName, string packageName, string projectName, string folderName, string environmentName)
        {
            return await ExecuteSsisAndWaitAsync(databaseName, packageName, projectName, folderName, environmentName, new List<SsisParameter>());
        }

        public async Task<int> ExecuteSsisAndWaitAsync(string databaseName, string packageName, string projectName, string folderName, string environmentName, IEnumerable<SsisParameter> ssisParams)
        {
            var ssisParameters = ssisParams.ToList();
            ssisParameters.Add(new SsisParameter()
            {
                Name = "SYNCHRONIZED",
                Value = "true",
                DataType = "System.Boolean",
                Level = SsisParameter.SsisParameterLevel.System
            });
            return await ExecuteSsisAsync(databaseName, packageName, projectName, folderName, environmentName, ssisParameters);
        }

        private static (string database, string schema, string table) SplitSchemaTableName(string schemaTableName)
        {
            var tableParts = schemaTableName.Split('.');

            switch (tableParts.Length)
            {
                case 1:
                    return (null, null, tableParts[0]);
                case 2:
                    return (null, tableParts[0], tableParts[1]);
                case 3:
                    return (tableParts[0], tableParts[1], tableParts[2]);
                default:
                    return (null, null, null);
            }
        }

        private async Task<IEnumerable<IDictionary<string, object>>> ExecProcAsync(string databaseName, string procName, IDictionary<string, object> parameters)
        {
            return (await GetConnection(databaseName).QueryAsync(procName, parameters, commandType: CommandType.StoredProcedure)).Select(d => (IDictionary<string, object>)d);
        }

        private async Task<long> GetSsisEnvironmentReferenceIdAsync(string databaseName, string projectName, string environmentName)
        {
            var getEvnReferenceIdSql = $@"SELECT reference_id
            FROM catalog.environment_references er
                JOIN catalog.projects p ON p.project_id = er.project_id
            WHERE er.environment_name = '{environmentName}'
            AND p.name = '{projectName}';";
            var envResult = (await GetConnection(databaseName).QueryAsync(getEvnReferenceIdSql)).Single();
            return envResult.reference_id;
        }

        private async Task<int> ExecuteSsisAsync(string databaseName, string packageName, string projectName, string folderName, string environmentName, IEnumerable<SsisParameter> ssisParams)
        {
            var executionId = await CreateSsisExecutionAsync(databaseName, packageName, projectName, folderName, environmentName);
            var ssisParameters = ssisParams.ToList();
            ssisParameters.Add(new SsisParameter()
            {
                Name = "LOGGING_LEVEL",
                Value = "1",
                DataType = "System.Int32",
                Level = SsisParameter.SsisParameterLevel.System
            });

            foreach (var param in ssisParameters)
            {
                await AddSsisParameterAsync(databaseName, executionId, param);
            }

            return await StartSsisExecutionAsync(databaseName, executionId);
        }

        private async Task<long> CreateSsisExecutionAsync(string databaseName, string packageName, string projectName, string folderName, string environmentName)
        {
            var parameters = new DynamicParameters();
            parameters.Add("package_name", $"{packageName.Replace(".dtsx", "")}.dtsx");
            parameters.Add("folder_name", folderName);
            parameters.Add("project_name", projectName);
            parameters.Add("reference_id", await GetSsisEnvironmentReferenceIdAsync(databaseName, projectName, environmentName));
            parameters.Add("execution_id", dbType: DbType.Int64, direction: ParameterDirection.Output);
            await GetConnection(databaseName).QueryAsync("catalog.create_execution", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<long>("execution_id");
        }

        private async Task AddSsisParameterAsync(string databaseName, long executionId, SsisParameter ssisParam)
        {
            var parameters = new DynamicParameters();
            parameters.Add("execution_id", executionId);
            parameters.Add("object_type", (int)ssisParam.Level);
            parameters.Add("parameter_name", ssisParam.Name);
            parameters.Add("parameter_value", Convert.ChangeType(ssisParam.Value, Type.GetType(ssisParam.DataType, true)));
            await ExecuteCommandAsync(databaseName, "catalog.set_execution_parameter_value", CommandType.StoredProcedure, parameters);
        }

        private async Task<int> StartSsisExecutionAsync(string databaseName, long executionId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("execution_id", executionId);
            var connection = GetConnection(databaseName);
            await connection.ExecuteAsync("catalog.start_execution", parameters, commandTimeout: _ssisTimeoutSeconds, commandType: CommandType.StoredProcedure);
            var sql = $"SELECT status from [SSISDB].[catalog].[executions] where execution_id = {executionId}";
            return await connection.ExecuteScalarAsync<int>(sql);
        }

        private void OpenConnection()
        {
            if (_connection.State != ConnectionState.Closed) return;

            try
            {
                TestContext.WriteLine($"Connecting to SQL Server: '{_connection.ConnectionString}'");
                _connection.Open();
            }
            catch
            {
                TestContext.Error.WriteLine($"Failed to connect to SQL Server: '{_connection.ConnectionString}'");
                throw;
            }
        }

        private IDbConnection GetConnection(string databaseName)
        {
            OpenConnection();
            if (string.Compare(_connection.Database, databaseName, StringComparison.OrdinalIgnoreCase) == 0) return _connection;

            try
            {
                TestContext.WriteLine($"Switching to database: '{databaseName}'");
                _connection.ChangeDatabase(databaseName);
                return _connection;
            }
            catch
            {
                TestContext.Error.WriteLine($"Unable to switch to database: '{databaseName}'");
                throw;
            }
        }

        public async Task InstallTsqltAsync(string databaseName)
        {
            await CreateSchemaAsync(databaseName, "tSQLt");
            await InstallScriptAsync(databaseName, "tSQLt.Private_SysTypes.svw.sql");
            await InstallScriptAsync(databaseName, "tSQLt.FakeFunction.ssp.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_CreateFakeFunction.ssp.sql");
            await InstallScriptAsync(databaseName, "tSQLt.SpyProcedure.ssp.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_CreateProcedureSpy.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_ValidateProcedureCanBeUsedWithSpyProcedure.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_GetFullTypeName.sfn.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_RenameObjectToUniqueName.ssp.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_RenameObjectToUniqueNameUsingObjectId.ssp.sql");
            await InstallScriptAsync(databaseName, "tSQLt.Private_ValidateObjectsCompatibleWithFakeFunction.ssp.sql");
            await InstallScriptAsync(databaseName, "tSQLt.RemoveObject.ssp.sql");
        }

        public async Task UninstallTsqltAsync(string databaseName)
        {
            await DropViewAsync(databaseName, "tSQLt.Private_SysTypes.svw.sql");
            await DropProcedureAsync(databaseName, "tSQLt.FakeFunction.ssp.sql");
            await DropProcedureAsync(databaseName, "tSQLt.Private_CreateFakeFunction.ssp.sql");
            await DropFunctionAsync(databaseName, "tSQLt.Private_GetFullTypeName.sfn.sql");
            await DropProcedureAsync(databaseName, "tSQLt.Private_RenameObjectToUniqueName.ssp.sql");
            await DropProcedureAsync(databaseName, "tSQLt.Private_RenameObjectToUniqueNameUsingObjectId.ssp.sql");
            await DropProcedureAsync(databaseName, "tSQLt.Private_ValidateObjectsCompatibleWithFakeFunction.ssp.sql");
            await DropProcedureAsync(databaseName, "tSQLt.SpyProcedure.ssp.sql");
            await DropProcedureAsync(databaseName, "tSQLt.Private_CreateProcedureSpy.sql");
            await DropProcedureAsync(databaseName, "tSQLt.Private_ValidateProcedureCanBeUsedWithSpyProcedure.sql");
            await DropProcedureAsync(databaseName, "tSQLt.RemoveObject.ssp.sql");
            await DropSchemaAsync(databaseName, "tSQLt");
        }

        public async Task DropTableAsync(string databaseName, string tableName)
        {
            await ExecuteCommandAsync(databaseName, $"drop table if exists {tableName}");
        }

        public void Dispose()
        {
            _connection?.Dispose();
        }

        private Task<int> ExecuteCommandAsync(string databaseName, string sql, IDictionary<string, object> rowData)
        {
            return GetConnection(databaseName).ExecuteAsync(sql, rowData, commandTimeout: _sqlCommandTimeoutSeconds);
        }

        private Task<int> ExecuteCommandAsync(string databaseName, string sql, SqlMapper.IDynamicParameters parameters = null)
        {
            return parameters != null
                ? GetConnection(databaseName).ExecuteAsync(sql, parameters, commandTimeout: _sqlCommandTimeoutSeconds)
                : GetConnection(databaseName).ExecuteAsync(sql, commandTimeout: _sqlCommandTimeoutSeconds);
        }

        private Task<int> ExecuteCommandAsync(string databaseName, string sql, CommandType commandType, SqlMapper.IDynamicParameters parameters = null)
        {
            return parameters != null
                ? GetConnection(databaseName).ExecuteAsync(sql, parameters, commandType: commandType, commandTimeout: _sqlCommandTimeoutSeconds)
                : GetConnection(databaseName).ExecuteAsync(sql, commandType: commandType, commandTimeout: _sqlCommandTimeoutSeconds);
        }

        private async Task CreateSchemaAsync(string databaseName, string schemeName)
        {
            if (!await CheckIfSchemaExistAsync(databaseName, schemeName))
                await ExecuteCommandAsync(databaseName, $"create schema {schemeName}");
        }

        private async Task DropSchemaAsync(string databaseName, string schemeName)
        {
            await ExecuteCommandAsync(databaseName, $"drop schema if exists {schemeName}");
        }

        private async Task DropProcedureAsync(string databaseName, string procedureName)
        {
            var parts = procedureName.Split('.');
            await ExecuteCommandAsync(databaseName, $"drop procedure if exists {parts[0]}.{parts[1]}");
        }

        private async Task DropFunctionAsync(string databaseName, string functionName)
        {
            var parts = functionName.Split('.');
            await ExecuteCommandAsync(databaseName, $"drop function if exists {parts[0]}.{parts[1]}");
        }

        private async Task DropViewAsync(string databaseName, string viewName)
        {
            var parts = viewName.Split('.');
            await ExecuteCommandAsync(databaseName, $"drop view if exists {parts[0]}.{parts[1]}");
        }

        private async Task<bool> CheckIfSchemaExistAsync(string databaseName, string schemaName)
        {
            return (await GetConnection(databaseName).QueryAsync<bool>($"SELECT cast(1 as bit) FROM sys.schemas as s where s.name = '{schemaName}'")).SingleOrDefault();
        }

        private async Task InstallScriptAsync(string databaseName, string scriptName)
        {
            var fileContents = EmbeddedResourceHandler.Read($"UnitTests.Framework.Database.tSqlt.{scriptName}");
            await ExecuteSqlScriptsAsync(databaseName, fileContents);
        }

        private async Task ExecuteSqlScriptsAsync(string databaseName, string fileContents)
        {
            foreach (var statement in fileContents.Split("\nGO"))
            {
                if (statement.Length < 1)
                    continue;

                try
                {
                    await ExecuteCommandAsync(databaseName, statement);
                }
                catch (SqlException)
                {
                    TestContext.WriteLine($"Error executing SQL statement:{Environment.NewLine}{statement}");
                    throw;
                }
            }
        }

        private async Task<string> GetObjectDefinitionAsync(string databaseName, string objectName)
        {
            var definition = (await GetConnection(databaseName).QueryAsync<string>($"select object_Definition( object_Id('{objectName}') )")).SingleOrDefault();
            if (definition != null && definition.Length == 0)
                throw new ArgumentException();
            return definition;
        }
    }
}