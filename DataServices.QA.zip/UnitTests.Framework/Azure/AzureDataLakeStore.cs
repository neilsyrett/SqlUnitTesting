﻿using System.IO;
using System.Linq;
using Microsoft.Azure.DataLake.Store;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Rest.Azure.Authentication;
using NUnit.Framework;

namespace UnitTests.Framework.Azure
{
    public class AzureDataLakeStore : IAzureDataLakeStore
    {
        private readonly AdlsClient _adlsClient;

        public AzureDataLakeStore(string domain, string accountName, string applicationId, string clientSecret)
        {
            var credential = new ClientCredential(applicationId, clientSecret);
            var serviceClientCredentials = ApplicationTokenProvider.LoginSilentAsync(domain, credential).Result;
            _adlsClient = AdlsClient.CreateClient(accountName, serviceClientCredentials);
            AccountName = accountName;
        }

        public string AccountName { get; }

        public void CreateFile(string path, Stream contents)
        {
            TestContext.WriteLine($"Creating file '{path}' on {AccountName} Data Lake");
            using (var adlsStream = _adlsClient.CreateFile(path, IfExists.Overwrite))
            {
                contents.CopyTo(adlsStream);
            }
        }

        public bool FolderContainsFiles(string folder)
        {
            TestContext.WriteLine($"Waiting for the folder '{folder}' on ADS Data Lake to contain a file");
            return _adlsClient.CheckExists(folder) && _adlsClient.EnumerateDirectory(folder).Any();
        }

        public void DeleteDirectory(string path)
        {
            TestContext.WriteLine($"Deleting directory '{path}' on {AccountName} Data Lake");
            _adlsClient.DeleteRecursive(path);
        }
    }
}