﻿using System.IO;
using System.Linq;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using UnitTests.Framework.Interfaces;

namespace UnitTests.Framework.Azure
{
    public class AzureBlobStore : IAzureBlobStore
    {
        private readonly CloudBlobClient _blobClient;

        public AzureBlobStore(string connectionString)
        {
            _blobClient = CloudStorageAccount.Parse(connectionString).CreateCloudBlobClient();
        }

        public void CreateFile(string path, Stream stream)
        {
            _blobClient.
                GetBlockBlobReference(path).
                UploadFromStreamAsync(stream).
                Wait();
        }

        public void CreateFile(string path, string text)
        {
            _blobClient.
                GetBlockBlobReference(path).
                UploadTextAsync(text).
                Wait();
        }

        public void DeleteAllFilesInDirectory(string path)
        {
            _blobClient.
                ListBlobsInDirectory(path, true).
                Where(blob => blob.GetType() == typeof(CloudBlockBlob)).
                ToList().
                ForEach(blob => ((CloudBlockBlob) blob).DeleteAsync().Wait());
        }
    }
}