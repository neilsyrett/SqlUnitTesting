﻿using System.Collections.Generic;
using System.Threading;
using Microsoft.Azure.Management.DataFactory;
using Microsoft.Azure.Management.DataFactory.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Rest;
using NUnit.Framework;

namespace UnitTests.Framework.Azure
{
    public class AzureDataFactory : IAzureDataFactory
    {
        private readonly string _subscriptionId;
        private readonly string _resourceGroup;
        private readonly string _dataFactoryName;
        private readonly string _applicationId;
        private readonly string _clientSecret;
        private readonly string _authority;
        private const string Resource = "https://management.azure.com/";
        private const int WaitPeriod = 1000;

        public AzureDataFactory(string tenantId, string subscriptionId, string resourceGroup, string dataFactoryName, string applicationId, string clientSecret)
        {
            _subscriptionId = subscriptionId;
            _resourceGroup = resourceGroup;
            _dataFactoryName = dataFactoryName;
            _applicationId = applicationId;
            _clientSecret = clientSecret;
            _authority = $"https://login.windows.net/{tenantId}";
        }

        public string ExecutePipeline(string pipelineName, IDictionary<string, object> parameters = null)
        {
            var dataFactoryManagementClient = CreateDataFactoryManagementClient();
            var runId = RunPipeline(dataFactoryManagementClient, pipelineName, parameters);
            TestContext.WriteLine($"the {pipelineName} pipeline run {runId} has started on ADF {_dataFactoryName}");
            return WaitUntilPipelineCompletes(dataFactoryManagementClient, runId, pipelineName);
        }

        private DataFactoryManagementClient CreateDataFactoryManagementClient()
        {
            var authenticationContext = new AuthenticationContext(_authority);
            var clientCredential = new ClientCredential(_applicationId, _clientSecret);
            var result = authenticationContext.AcquireTokenAsync(Resource, clientCredential).Result;
            var tokenCredentials = new TokenCredentials(result.AccessToken);
            return new DataFactoryManagementClient(tokenCredentials)
            {
                SubscriptionId = _subscriptionId
            };
        }

        private string RunPipeline(IDataFactoryManagementClient dataFactoryManagementClient, string pipelineName, IDictionary<string, object> parameters)
        {
            return dataFactoryManagementClient.Pipelines.CreateRunWithHttpMessagesAsync(_resourceGroup, _dataFactoryName, pipelineName, parameters: parameters).Result.Body.RunId;
        }

        private string WaitUntilPipelineCompletes(IDataFactoryManagementClient dataFactoryManagementClient, string runId, string pipelineName)
        {
            PipelineRun pipelineRun;
            do
            {
                TestContext.WriteLine($"the {pipelineName} pipeline is still executing...");
                Thread.Sleep(WaitPeriod);
                pipelineRun = dataFactoryManagementClient.PipelineRuns.Get(_resourceGroup, _dataFactoryName, runId);
            } while (pipelineRun.Status == "InProgress");

            return pipelineRun.Status;
        }
    }
}