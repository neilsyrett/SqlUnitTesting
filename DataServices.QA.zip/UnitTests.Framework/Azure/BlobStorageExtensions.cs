﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.WindowsAzure.Storage.Blob;

namespace UnitTests.Framework.Azure
{
    internal static class BlobStorageExtensions
    {
        internal static CloudBlockBlob GetBlockBlobReference(this CloudBlobClient cloudBlobClient, string path)
        {
            return cloudBlobClient.
                GetContainerReference(path.GetContainer()).
                GetBlockBlobReference(path.GetBlobReference());
        }

        internal static IEnumerable<IListBlobItem> ListBlobsInDirectory(this CloudBlobClient cloudBlobClient, string path, bool useFlatBlobListing=false)
        {
            BlobContinuationToken continuationToken = null;
            do
            {
                var listingResult = cloudBlobClient.
                GetContainerReference(path.GetContainer()).
                GetDirectoryReference(path.GetBlobReference()).
                ListBlobsSegmentedAsync(
                    useFlatBlobListing,
                    BlobListingDetails.None,
                    null,
                    continuationToken,
                    null,
                    null).Result;

                continuationToken = listingResult.ContinuationToken;

                foreach (var listBlobItem in listingResult.Results) yield return listBlobItem;
            }
            while (continuationToken != null);
        }

        private static string GetContainer(this string path)
        {
            return path.Split('/')[0];
        }

        private static string GetBlobReference(this string path)
        {
            return string.Join("/", path.Split('/').Skip(1));
        }
    }
}