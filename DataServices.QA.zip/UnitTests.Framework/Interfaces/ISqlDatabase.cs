﻿namespace UnitTests.Framework.Interfaces
{
    public interface ISqlDatabase : ISqlDatabaseData, ISqlDatabaseExec, ISqlDatabaseMock, ISqlDatabaseSchema
    {
    }
}