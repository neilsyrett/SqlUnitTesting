﻿using System.IO;

namespace UnitTests.Framework.Azure
{
    public interface IAzureDataLakeStore
    {
        string AccountName { get; }
        void CreateFile(string path, Stream contents);
        bool FolderContainsFiles(string folder);
        void DeleteDirectory(string path);
    }
}