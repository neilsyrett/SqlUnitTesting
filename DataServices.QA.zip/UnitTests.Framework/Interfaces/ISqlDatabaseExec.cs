﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Steps.Helpers;
using TechTalk.SpecFlow;

namespace UnitTests.Framework.Interfaces
{
    public interface ISqlDatabaseExec
    {
        Task<IEnumerable<IDictionary<string, object>>> ExecProcAsync(string databaseName, string procName, Table parameters);
        Task<IEnumerable<IDictionary<string, object>>> ExecProcAsync(string databaseName, string procName);
        Task<IEnumerable<IDictionary<string, object>>> ExecProcWithResultsAsync(string databaseName, string procName, IDictionary<string, object> parameters);
        Task<int> ExecuteSsisAndWaitAsync(string databaseName, string packageName, string projectName, string folderName, string environmentName);
        Task<int> ExecuteSsisAndWaitAsync(string databaseName, string packageName, string projectName, string folderName, string environmentName, IEnumerable<SsisParameter> ssisParams);
    }
}