﻿using System.Threading.Tasks;

namespace UnitTests.Framework.Interfaces
{
    public interface ISqlDatabaseMock
    {
        Task MockViewAsync(string databaseName, string viewName);
        Task MockProcedureAsync(string databaseName, string procedureName, string commandToExecute = null);
        Task FakeFunctionAsync(string databaseName, string fqViewName, string returnSql);
        Task UnMockViewAsync(string databaseName);
        Task InstallTsqltAsync(string databaseName);
        Task UninstallTsqltAsync(string databaseName);
    }
}