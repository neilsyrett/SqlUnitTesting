﻿using System.IO;

namespace UnitTests.Framework.Interfaces
{
    public interface IAzureBlobStore
    {
        void CreateFile(string path, Stream stream);
        void CreateFile(string path, string text);
        void DeleteAllFilesInDirectory(string path);
    }
}