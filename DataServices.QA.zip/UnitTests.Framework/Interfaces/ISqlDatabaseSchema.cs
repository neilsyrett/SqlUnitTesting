﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UnitTests.Framework.Helpers;

namespace UnitTests.Framework.Interfaces
{
    public interface ISqlDatabaseSchema
    {
        Task<List<Dictionary<string, string>>> GetForeignKeysNamesFromTable(string databaseName, string tableName);
        Task DropForeignKeyContraint(string databaseName, string fullTableName, string foreignKeyName);
        Task DropForeignKeyConstraintsFromTable(string databaseName, string tableNameWithSchema);
        Task DropViewsWithSchemaBindingToTable(string databaseName, string tableNameWithSchema);
        Task<List<string>> GetViewNamesWithSchemaBindingToTable(string databaseName, string schemaName, string tableName);
        Task<IEnumerable<IDictionary<string, object>>> ReadColumnDetailsAsync(string databaseName, string tableName, IEnumerable<string> columnsToIgnore = null);
        Task DropNotNullConstraintsAsync(string databaseName, string name);
        
        Task DropTableAsync(string databaseName, string tableName);
    }
}