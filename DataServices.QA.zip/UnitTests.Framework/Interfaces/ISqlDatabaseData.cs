﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UnitTests.Framework.Helpers;

namespace UnitTests.Framework.Interfaces
{
    public interface ISqlDatabaseData
    {
        Task InsertAsync(string databaseName, string tableName, TypedTable table);
        Task InsertAsync(string databaseName, string name, IEnumerable<Dictionary<string, object>> rows);
        Task SelectIntoAsync(string databaseName, string tableName, TypedTable table);
        Task<IEnumerable<IDictionary<string, object>>> ReadAllAsync(string databaseName, string tableName);
        Task TruncateAsync(string databaseName, string tableName);
    }
}