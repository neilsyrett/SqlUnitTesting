﻿using System.Collections.Generic;

namespace UnitTests.Framework.Azure
{
    public interface IAzureDataFactory
    {
        string ExecutePipeline(string pipelineName, IDictionary<string, object> parameters = null);
    }
}