﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Parquet;
using Parquet.Data;
using TechTalk.SpecFlow;

namespace UnitTests.Framework.Helpers
{
    public static class ParquetFileGenerator
    {
        public static Stream Generate(TypedTable table)
        {
            var dataFields = table.ColumnTypes.Select(kvp => new DataField(kvp.Key, kvp.Value)).ToList();
            var schema = new Schema(dataFields);
            var memoryStream = new MemoryStream();
            using (var parquetWriter = new ParquetWriter(schema, memoryStream))
            using (var groupWriter = parquetWriter.CreateRowGroup())
            {
                foreach (var columnName in table.Header)
                {
                    var dataColumn = CreateDataColumn(columnName, table, table.ColumnTypes, dataFields);
                    groupWriter.WriteColumn(dataColumn);
                }
            }

            memoryStream.Seek(0, SeekOrigin.Begin);
            return memoryStream;
        }

        private static DataColumn CreateDataColumn(string columnName, Table table, IReadOnlyDictionary<string, Type> columnTypes, IEnumerable<DataField> dataFields)
        {
            var columnType = columnTypes[columnName];
            var values = CreateTypedList(columnType);
            foreach (var tableRow in table.Rows)
            {
                dynamic value;
                if (columnType == typeof(DateTimeOffset))
                {
                    value = DateTimeOffset.Parse((string) tableRow[columnName]);
                }
                else
                {
                    value = Convert.ChangeType(tableRow[columnName], columnType);
                }

                values.Add(value);
            }

            var data = values.ToArray();
            var dataField = dataFields.First(col => col.Name == columnName);
            return new DataColumn(dataField, data);
        }

        private static dynamic CreateTypedList(Type type)
        {
            var genericListType = typeof(List<>).MakeGenericType(type);
            return Activator.CreateInstance(genericListType);
        }
    }
}