﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Transactions;
using UnitTests.Framework.Azure;
using UnitTests.Framework.Database;
using UnitTests.Framework.Interfaces;

namespace UnitTests.Framework.Helpers
{
    public class Context
    {
        public ISqlDatabase Database;
        public readonly IList<string> Databases = new List<string>();
        public readonly Dictionary<string, IAzureBlobStore> BlobStores = new Dictionary<string, IAzureBlobStore>();
        public readonly Dictionary<string, IAzureDataFactory> DataFactories = new Dictionary<string, IAzureDataFactory>();
        public readonly Dictionary<string, IAzureDataLakeStore> DataLakeStores = new Dictionary<string, IAzureDataLakeStore>();
        public Type Exception { get; set; }
        public TransactionScope TransactionScope { get; set; }
        public IEnumerable<IDictionary<string, object>> ResultSet { get; set; }

        public IAzureBlobStore GetBlobStore(string name)
        {
            return BlobStores.Single(dbs => string.Equals(dbs.Key, name, StringComparison.OrdinalIgnoreCase)).Value;
        }

        public IAzureDataFactory GetDataFactory(string name)
        {
            return DataFactories.Single(dbs => string.Equals(dbs.Key, name, StringComparison.OrdinalIgnoreCase)).Value;
        }

        public IAzureDataLakeStore GetDataLakeStore(string name)
        {
            return DataLakeStores.Single(dbs => string.Equals(dbs.Key, name, StringComparison.OrdinalIgnoreCase)).Value;
        }

        public void Reset()
        {
            Exception = null;
            TransactionScope = null;
        }
    }
}