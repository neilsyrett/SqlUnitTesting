﻿namespace Steps.Helpers
{
    public class SsisParameter
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public string DataType { get; set; }
        public SsisParameterLevel Level { get; set; }

        public enum SsisParameterLevel
        {
            System = 50,
            Package = 30,
            Project = 20
        }
    }
}
