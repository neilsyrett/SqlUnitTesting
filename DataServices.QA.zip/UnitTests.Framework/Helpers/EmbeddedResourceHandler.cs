﻿using System;
using System.IO;
using System.Reflection;

namespace UnitTests.Framework.Helpers
{
    public class EmbeddedResourceHandler
    {
        public static string Read(string resourceName)
        {
            string fileContents;
            using (var stream = Assembly.GetExecutingAssembly()
                .GetManifestResourceStream(resourceName))
            {
                using (TextReader tr = new StreamReader(stream ?? throw new InvalidOperationException()))
                {
                    fileContents = tr.ReadToEnd();
                }
            }

            return fileContents;
        }
    }
}